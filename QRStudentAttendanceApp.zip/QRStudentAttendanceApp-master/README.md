Android QRStudentAttendance Project using Zxing Library.
